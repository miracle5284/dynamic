from django.contrib import admin
from .models import *

@admin.register(ZipFiles)
class ZipFilesAdmin(admin.ModelAdmin):
    pass