from django.db import models

# Create your models here.
class ZipFiles(models.Model):
    file_name = models.CharField(max_length=255)
    file_path = models.FileField(upload_to='files/compressed')
    description = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return self.file_name
