from rest_framework.routers import SimpleRouter, DefaultRouter
from .views import *
from django.urls import path, include
from rest_framework.urlpatterns import format_suffix_patterns


routers = SimpleRouter(trailing_slash=False, use_regex_path=False)
routers.register(r'zipfile/', ZipFileViewSet, basename='zip')
# routers.register(r'files/', FilesViews, basename='files')

urlpatterns = [
    path(r'zip-serve/', include(routers.urls)),
    path(r'zip-serve/files', FilesViews.as_view(), name='zip-serve-files'),
]
