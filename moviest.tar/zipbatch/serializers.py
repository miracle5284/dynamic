from rest_framework.serializers import ModelSerializer
from .models import  ZipFiles
import zipfile
from rest_framework.validators import ValidationError


class ZipFileSerializer(ModelSerializer):

    class Meta:
        model = ZipFiles
        fields = '__all__'


    def validate(self, attrs):
        file = attrs['file_path']
        if not zipfile.is_zipfile(file):
            raise ValidationError('Uploaded file is not a ZIP file')
        return super().validate(attrs)
