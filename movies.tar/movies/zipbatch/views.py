from rest_framework import status

from .serializers import ZipFileSerializer
from .models import ZipFiles
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
import zipfile
import os


class ZipFileViewSet(ModelViewSet):

    queryset = ZipFiles.objects.all()
    serializer_class = ZipFileSerializer


class FilesViews(APIView):

    serializer_class = ZipFileSerializer
    permission_classes = [AllowAny]


    def post(self, request):
        serializer = ZipFileSerializer(data=request.data)
        if serializer.is_valid():
            file = serializer.validated_data['file_path']
            file_size = file.size/1024
            with zipfile.ZipFile(file) as zf:
                file_info = [{"name": info.filename,
                             "size": info.file_size,
                             "compressed_size": info.compress_size
                        } for info in zf.infolist()]
            return Response({'file_name': file.name, "size": f'{file_size:.2f} KB', 'files': file_info})
        return Response({'err': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)